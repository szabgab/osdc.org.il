#!/usr/bin/env python
'''Regression tests for "echo"'''

# "out" directory contains the current output
# "gold" directory contains the desired output

# Miki Tebeka <mtebeka@qualcomm.com>

from unittest import TestCase, main
from os import system
from os.path import join, isfile, basename
from glob import glob
from md5 import md5

def file_signature(filename):
    '''Didital signature of file
        
        filename - Name of file to generate signature
    '''
    return md5(open(filename, "rb").read()).hexdigest()

def differ(f1, f2):
    '''Check if two files differ
    
        f1 - First file
        f2 - Second file
    '''
    return file_signature(f1) != file_signature(f2)

class TestEcho(TestCase):
    def runtest(self, name, arguments):
        '''Run test
        
            name - Test name
            arguments - Test arguments
        '''

        outfile = join("out", name)
        goldfile = join("gold", name)

        # Run program
        if system("echo %s > %s 2>&1" % (" ".join(arguments), outfile)) != 0:
            self.fail("non-zero value return")

        # Check output
        if differ(outfile, goldfile):
            self.fail("output for %s differs" % name)

def add_test(name, arguments):
    '''Add a test "name" with "arguments"

        name - Test name
        arguments - Test arguments

    Note: "name" must be qualified Python variable name
    '''

    def t(self):
        self.runtest(name, arguments)

    t.func_doc = "Testing %s" % name
    setattr(TestEcho, "test_%s" % name, t)

# Add all tests to out test class
for test in glob(join("gold", "*")):
    if not isfile(test):
        continue

    test = basename(test)
    add_test(test, [test])

# Main
if __name__ == "__main__":
    main()
