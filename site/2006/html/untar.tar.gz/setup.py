from distutils.core import setup
import py2exe

setup( 
    windows = [ 
        { 
            "script": "untar.py", 
            "icon_resources": [(1, "tar.ico")] 
        } 
    ]
)
