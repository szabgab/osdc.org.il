'''Open Tar Archivers'''

# Miki Tebeka <miki.tebeka@gmail.com>

import wx
from wx.lib.filebrowsebutton import FileBrowseButton, DirBrowseButton

from tarfile import is_tarfile, open as taropen
from sys import path
from os.path import isfile, dirname, join, isdir
from os import makedirs

FILEMASK = "Tar Files|*.tar;*.tgz;*.tar.gz;*.tar.bz2|All Files|*.*"
WIDTH = 600

class UnTarDlg(wx.Dialog):
    '''Main dialog'''
    def __init__(self):
        # Enable resize
        wx.Dialog.__init__(self, None, -1, "UnTar for Windows",
                style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER)

        # Icon
        appdir = path[0]
        if isfile(appdir): # py2exe
            appdir = dirname(appdir)

        iconfile = join(appdir, "tar.ico")
        if isfile(iconfile):
            icon = wx.Icon(iconfile, wx.BITMAP_TYPE_ICO)
            self.SetIcon(icon)

        sizer = wx.BoxSizer(wx.VERTICAL)
        # Tar File: _____ [Browse]
        self._filename = FileBrowseButton(self, -1, labelText="Tar File:",
                fileMask=FILEMASK, fileMode=wx.OPEN|wx.FILE_MUST_EXIST,
                size=(WIDTH, -1))
        sizer.Add(self._filename, 0, wx.EXPAND)
        # Output Directory: _____ [Browse]
        self._outdir = DirBrowseButton(self, -1, labelText="Output Directory:",
                newDirectory=1, 
                dialogTitle="Select directory to extract files to", 
                size=(WIDTH, -1))
        sizer.Add(self._outdir, 0, wx.EXPAND)

        sizer.Add(wx.StaticLine(self, -1, style=wx.LI_HORIZONTAL), 0,
                wx.EXPAND|wx.ALL, 5)

        # [Extract] [Quit]
        hsizer = wx.BoxSizer(wx.HORIZONTAL)
        b = wx.Button(self, -1, "Extract")
        self.Bind(wx.EVT_BUTTON, self.OnExtract, b)
        hsizer.Add(b)
        hsizer.Add((1,1), 1, wx.EXPAND) # Spacer
        hsizer.Add(wx.Button(self, wx.ID_CANCEL, "Quit"))
        sizer.Add(hsizer, 1, wx.EXPAND)

        # Layout window
        self.SetSizer(sizer)
        self.SetAutoLayout(1)
        sizer.Fit(self)
        self.CenterOnScreen()

    def OnExtract(self, evt):
        '''Handle "Extract" click'''
        # Get values from UI
        try:
            filename = self.get(self._filename, 
                    "Please enter a file name to extract")
            outdir = self.get(self._outdir, 
                    "Please enter an output directory")
        except ValueError, e:
            self.error(e)
            return

        # Check that file is valid
        if not self.is_tarfile(filename):
            self.error("%s is not a valid tar file" % filename)
            return

        # Create output directory
        if not isdir(outdir):
            try:
                makedirs(outdir)
            except OSError, e:
                self.error("Can't create output directory %s:\n\n%s" % (outdir, e))
                return

        # Extract files with progress bar
        tar = taropen(filename)
        members = tar.getmembers()

        # Find longest name
        maxname = " " * (max([len(m.name) for m in members]))

        def ex(name):
            return "Extracting %s..." % name

        dlg = wx.ProgressDialog("Extracting Files", ex(maxname), len(members),
                style=wx.PD_ELAPSED_TIME|wx.PD_REMAINING_TIME)

        for i, m in enumerate(members):
            dlg.Update(i, ex(m.name))
            tar.extract(m, outdir)

        dlg.Destroy()

    def error(self, msg):
        '''Show an error message'''
        msg = str(msg) # Make sure it's a string
        dlg = wx.MessageDialog(self, msg, "UnTar Error", wx.OK|wx.ICON_ERROR)
        dlg.ShowModal()
        dlg.Destroy()
    
    def get(self, ctrl, error):
        '''Get value from file/dir control. Raise ValueError if empty'''
        val = ctrl.GetValue().strip()
        if not val:
            raise ValueError(error)

        return val

    def is_tarfile(self, filename):
        '''Check if a filename exists and is somethig tarfile can handle'''
        try:
            return is_tarfile(filename)
        except IOError: # File don't exist
            return 0


# MAIN
if __name__ == "__main__":
    app = wx.PySimpleApp()
    dlg = UnTarDlg()
    dlg.ShowModal()
    dlg.Destroy()
