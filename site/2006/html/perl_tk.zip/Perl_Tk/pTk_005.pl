#!/usr/local/bin/perl5.6.1
use Tk;
use Tk::FileSelect;
use File::Spec;
use Cwd;

use strict;
use warnings;

my $curdir = cwd;
my %curfiles;

my $mw = MainWindow->new;
$mw->title("Perl::Tk Demo");

my $menuFrame        = $mw->Frame->pack(-fill=>'x');
my $fileSelectFrame  = $mw->Frame->pack;
my $manualFileFrame  = $fileSelectFrame->Frame->pack(-side => 'left');
my $autoFileFrame    = $fileSelectFrame->Frame->pack(-side => 'right', -fill => 'y');
my $fileDisplayFrame = $mw->Frame->pack;

my $mainMenu = $menuFrame->Menubutton(
	-tearoff => 0,
	-text=>'Menu',
)->pack(
	-side =>'left',
);
$mainMenu->command(
	-label=>'Exit',
	-command=>'exit',
);

$menuFrame->Label(
	-text=>'File Display GUI',
	-font=>'-adobe-courier-bold-r-normal-*-*-120-*-*-m-*-koi8-1'
)->pack(
	-padx=>10
);

my $text;

&displayDirAndFiles($manualFileFrame, \$curdir, \%curfiles, \$text);

MainLoop;

sub displayDirAndFiles {
	my $parent   = shift;
	my $dirRef   = shift;
	my $filesRef = shift;
	my $textRef  = shift;

	Tk::destroy($_) for ($parent->children);
	
	chdir $$dirRef;
	opendir(DIR,".") or die $!;
	my @dir = sort readdir DIR;
	closedir DIR;
	
	my @dirs = grep {-d $_} @dir;
	my @files = grep {-f $_} @dir;

	my $mainFrame = $parent->Frame->pack;
	my $entryFrame =$parent->Frame->pack;
	my $dirFrame  = $mainFrame->Frame->pack(-side => 'left', -anchor => 'n',);
	my $fileFrame = $mainFrame->Frame->pack(-side => 'right', -anchor => 'n');
	
	foreach (@dirs) {
		$dirFrame->Radiobutton(
			-value => $_,
			-variable => $dirRef,
			-text => $_,
		)->pack(
			-anchor => 'nw'
		);
	}
	$dirFrame->Button(
		-text => 'Change Dir',
		-command => [sub {&displayDirAndFiles($mainFrame, $dirRef, $filesRef, $textRef)}],
	)->pack(
		-side => 'left',
	);


	%$filesRef = ();
	foreach my $fl (@files) {
		my $cb	= $fileFrame->Checkbutton;
		$cb -> configure(
			-text => $fl,
			-command => [
				sub{if (${$_[0]->cget(-variable)}) 
					{$filesRef->{$fl} = 1} 
					else {delete $filesRef->{$fl}}
				}, $cb],
		);
		$cb->pack(
			-anchor => 'nw',
		);
	}

	$fileFrame->Button(
		-text => 'Display Files',
		-command => [sub{&displayFileContents($text, $filesRef)}],
	)->pack(
		-anchor => 'w',
	);

	my $entry = $entryFrame->Entry->pack(-side=>'left');
	$entryFrame->Button(
		-text => 'Manual Select',
		-command => [
			sub{	%$filesRef = (); 
				$filesRef->{$entry->get}=1; 
				&displayFileContents($textRef, $filesRef)
			}],
	)->pack(-side=>'right');
		
	
	
}

sub displayFileContents{
}
