#!/usr/local/bin/perl5.6.1
use Tk;

use strict;
use warnings;


my $mw = MainWindow->new;
$mw->title("Perl::Tk Demo");

my $menuFrame        = $mw->Frame->pack(-fill=>'x');
my $fileSelectFrame  = $mw->Frame->pack;
my $manualFileFrame  = $fileSelectFrame->Frame->pack(-side => 'left');
my $autoFileFrame    = $fileSelectFrame->Frame->pack(-side => 'right', -fill => 'y');
my $fileDisplayFrame = $mw->Frame->pack;

MainLoop;


