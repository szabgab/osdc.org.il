#!/usr/local/bin/perl5.6.1

package Ball;

use Data::Dumper;

sub new {
  my $class = shift;
  
  my $self = {
	      X => shift,
	      Y => shift,
	      RADIUS => shift,
	      VX => shift,
	      VY => shift,
	     };
  
  bless $self;
}

sub draw {
  my $self = shift;
  my $canvas = shift;
  
  my $widget_item = 
    $canvas->createOval($self->{X} - $self->{RADIUS},
			$self->{Y} - $self->{RADIUS},
			$self->{X} + $self->{RADIUS},
			$self->{Y} + $self->{RADIUS},
			-fill => 'blue',
			-tags => 'ball');
  
  $self->{WIDGET_ITEM} = $widget_item;
}

sub top {
  my $self = shift;
  return $self->{Y} - $self->{RADIUS};
}
sub bottom {
  my $self = shift;
  return $self->{Y} + $self->{RADIUS};
}
sub left {
  my $self = shift;
  return $self->{X} - $self->{RADIUS};
}
sub right {
  my $self = shift;
  return $self->{X} + $self->{RADIUS};
}

sub handleBounce {
  my $self = shift;
  
  my $position = shift;
  my $velocity_field = shift;
  my ($delta, $max) = @_;
  
  my $maxpos = $position + $self->{RADIUS};
  my $minpos = $position - $self->{RADIUS};
  
  if ($maxpos + $delta >= $max) {
    $delta = $max - $maxpos - 1;
    $self->{$velocity_field} = - $self->{$velocity_field};
  }
  elsif ($minpos + $delta <= 0) {
    $delta = - $minpos;
    $self->{$velocity_field} = - $self->{$velocity_field};
  }
  
  return $delta;
}

sub move {
  my $self = shift;
  my $canvas = shift;
  my ($dx, $dy) = ($self->{VX}, $self->{VY});
  
  $dx = $self->handleBounce($self->{X}, 'VX',
			    $dx, $canvas->width);

  $dy = $self->handleBounce($self->{Y}, 'VY',
			    $dy, $canvas->height);

  $self->{X} += $dx;
  $self->{Y} += $dy;
  
  $canvas->move($self->{WIDGET_ITEM}, $dx, $dy);
}

sub dump {
  my $self = shift;
  print Dumper($self), "\n";
}

package __MAIN__;

use Tk;
use strict;
use warnings;

use Data::Dumper;
use Tk::Frame;

my $canvas;

sub createBall {
  my ($center_x, $center_y, $radius, $vx, $vy) = @_;
  
  $vx = 1 if !defined $vx;
  $vy = 1 if !defined $vy;
  
  my $ball = Ball->new($center_x, $center_y, $radius, $vx, $vy);
  $ball->draw($canvas);
  return $ball;
}

my $stopped = 0;
sub stop { $stopped = 1; }
sub go { $stopped = 0; }

my @all;

sub move_all {
  return if $stopped;
  
  map { $_->move($canvas); } @all;
  $canvas->idletasks;
}

my $top = MainWindow->new;

$canvas = $top->Canvas(-height => 100, -width => 300, -bg => 'white')->
  pack(-padx => 8, -pady => 8);

# Make sure canvas width and height are accurately returned
$canvas->update;

$canvas->Tk::bind('all', '<Escape>', sub { exit(0) } );

push @all, createBall(40, 60, 10, 2, 2);
push @all, createBall(230, 30, 5, -1.5, 1);
push @all, createBall(180, 80, 15, .9, -1.4);

print Dumper(@all), "\n";

$canvas->repeat(5, \&move_all);

$canvas->Tk::bind('<Button-1>', \&stop);
$canvas->Tk::bind('<Button-3>', \&go);


MainLoop;
