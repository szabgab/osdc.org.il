#!/usr/local/bin/perl5.6.1
use Tk;
use Tk::FileSelect;
use File::Spec;
use Cwd;

use strict;
use warnings;

my $curdir = cwd;
my %curfiles;

my $mw = MainWindow->new;
$mw->title("Perl::Tk Demo");

my $menuFrame        = $mw->Frame->pack(-fill=>'x');
my $fileSelectFrame  = $mw->Frame->pack;
my $manualFileFrame  = $fileSelectFrame->Frame->pack(-side => 'left');
my $autoFileFrame    = $fileSelectFrame->Frame->pack(-side => 'right', -fill => 'y');
my $fileDisplayFrame = $mw->Frame->pack;

my $mainMenu = $menuFrame->Menubutton(
	-tearoff => 0,
	-text=>'Menu',
)->pack(
	-side =>'left',
);
$mainMenu->command(
	-label=>'Exit',
	-command=>'exit',
);

MainLoop;
